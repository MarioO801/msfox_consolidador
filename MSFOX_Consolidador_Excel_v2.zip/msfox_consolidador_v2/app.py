from __future__ import annotations

import io
from datetime import datetime
from typing import Iterable

import pandas as pd
import streamlit as st
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

st.set_page_config(
    page_title="MS FOX | Consolidador Excel",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ----------------------------- Configuración ---------------------------------
REQUIRED = ["fecha", "cliente", "categoria", "importe"]
ALIASES = {
    "fecha": ["fecha", "date", "fecha venta", "fecha_transaccion", "fecha compra"],
    "cliente": ["cliente", "customer", "nombre cliente", "razon social", "proveedor"],
    "categoria": ["categoria", "categoría", "category", "rubro", "tipo"],
    "importe": ["importe", "monto", "total", "amount", "venta", "valor", "importe total"],
}
BRAND = "MS FOX"
CURRENCY_LABEL = "Gs."

st.markdown("""
<style>
    .block-container {padding-top: 1.5rem; padding-bottom: 2.5rem;}
    .msfox-eyebrow {font-size: .78rem; letter-spacing: .14em; text-transform: uppercase; color: #47708e; font-weight: 700;}
    .msfox-title {font-size: 2rem; font-weight: 800; line-height: 1.15; color: var(--text-color);}
    .msfox-subtitle {color: var(--text-color); opacity: .72; font-size: 1rem;}
    div[data-testid="stMetric"] {border: 1px solid rgba(128,128,128,.25); padding: 12px 14px; border-radius: 12px;}
</style>
""", unsafe_allow_html=True)

def norm_name(value: object) -> str:
    return str(value).strip().lower().replace("_", " ")

def normalize_columns(frame: pd.DataFrame) -> pd.DataFrame:
    renames = {}
    for col in frame.columns:
        normalized = norm_name(col)
        for canonical, aliases in ALIASES.items():
            if normalized in {norm_name(a) for a in aliases}:
                renames[col] = canonical
                break
    return frame.rename(columns=renames)

def read_uploaded_file(uploaded_file) -> pd.DataFrame:
    filename = uploaded_file.name.lower()
    content = uploaded_file.getvalue()
    if filename.endswith(".csv"):
        last_error = None
        for encoding in ("utf-8-sig", "latin-1"):
            try:
                return pd.read_csv(io.BytesIO(content), sep=None, engine="python", encoding=encoding)
            except Exception as exc:
                last_error = exc
        raise ValueError(f"No se pudo leer el CSV: {last_error}")
    if filename.endswith(".xlsx"):
        return pd.read_excel(io.BytesIO(content), engine="openpyxl")
    raise ValueError("Formato no admitido. Usá archivos .xlsx o .csv.")

def parse_amount(series: pd.Series) -> pd.Series:
    if pd.api.types.is_numeric_dtype(series):
        return pd.to_numeric(series, errors="coerce")
    amount = series.astype("string").str.strip().str.replace(r"[\s₲$]", "", regex=True)
    has_comma = amount.str.contains(",", na=False)
    has_dot = amount.str.contains(r"\.", na=False)
    both = has_comma & has_dot
    # Convention for this demo: 1.234,56 -> 1234.56
    amount.loc[both] = amount.loc[both].str.replace(".", "", regex=False).str.replace(",", ".", regex=False)
    comma_only = has_comma & ~has_dot
    amount.loc[comma_only] = amount.loc[comma_only].str.replace(",", ".", regex=False)
    return pd.to_numeric(amount, errors="coerce")

def clean_file(frame: pd.DataFrame, filename: str) -> pd.DataFrame:
    frame = normalize_columns(frame.copy())
    missing = [col for col in REQUIRED if col not in frame.columns]
    if missing:
        raise ValueError(
            f"Faltan columnas obligatorias: {', '.join(missing)}. "
            "Se esperan Fecha, Cliente, Categoria e Importe."
        )
    frame = frame[REQUIRED].copy()
    frame["fecha"] = pd.to_datetime(frame["fecha"], errors="coerce", dayfirst=True)
    frame["cliente"] = frame["cliente"].astype("string").str.strip()
    frame["categoria"] = frame["categoria"].astype("string").str.strip()
    frame["importe"] = parse_amount(frame["importe"])
    frame["archivo_origen"] = filename
    frame["fila_origen"] = range(2, len(frame) + 2)
    frame["error_validacion"] = ""
    frame.loc[frame["fecha"].isna(), "error_validacion"] += "Fecha inválida; "
    frame.loc[frame["cliente"].isna() | (frame["cliente"] == ""), "error_validacion"] += "Cliente vacío; "
    frame.loc[frame["categoria"].isna() | (frame["categoria"] == ""), "error_validacion"] += "Categoría vacía; "
    frame.loc[frame["importe"].isna(), "error_validacion"] += "Importe inválido; "
    return frame

def money(value: float) -> str:
    try:
        return f"Gs. {value:,.0f}".replace(",", ".")
    except (ValueError, TypeError):
        return "Gs. 0"

def build_excel_bytes(sheets: dict[str, pd.DataFrame], company: str, period: str, generated_at: str) -> bytes:
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl", datetime_format="dd/mm/yyyy") as writer:
        # Executive cover sheet
        cover = pd.DataFrame([
            ["MS FOX | CONSOLIDADOR EXCEL", ""],
            ["Empresa", company],
            ["Período procesado", period],
            ["Generado el", generated_at],
            ["", ""],
            ["Contenido", "Descripción"],
            ["Resumen ejecutivo", "Indicadores y agrupaciones del procesamiento"],
            ["Consolidado", "Registros válidos originales, incluidas filas repetidas"],
            ["Duplicados", "Todas las apariciones de registros que coinciden según la regla elegida"],
            ["Errores", "Filas que no superaron las validaciones básicas"],
        ], columns=["Reporte", "Detalle"])
        cover.to_excel(writer, index=False, sheet_name="Portada")
        for name, frame in sheets.items():
            safe_name = name[:31]
            export = frame.copy()
            for col in export.columns:
                if pd.api.types.is_datetime64_any_dtype(export[col]):
                    export[col] = export[col].dt.strftime("%d/%m/%Y")
            export.to_excel(writer, index=False, sheet_name=safe_name)

        for ws in writer.book.worksheets:
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions if ws.max_row > 1 else None
            ws.sheet_view.showGridLines = False
            for cell in ws[1]:
                cell.font = Font(bold=True, color="FFFFFF", size=11)
                cell.fill = PatternFill("solid", fgColor="173B57")
                cell.alignment = Alignment(vertical="center", wrap_text=True)
            ws.row_dimensions[1].height = 28
            for column_cells in ws.columns:
                idx = column_cells[0].column
                max_len = max((len(str(c.value)) if c.value is not None else 0) for c in column_cells[:250])
                ws.column_dimensions[get_column_letter(idx)].width = min(max(max_len + 2, 12), 36)
            # Format amount columns
            headers = {cell.column: str(cell.value).strip().lower() for cell in ws[1]}
            for col_idx, header in headers.items():
                if any(term in header for term in ("importe", "total", "monto", "valor")):
                    for row in range(2, ws.max_row + 1):
                        ws.cell(row=row, column=col_idx).number_format = '#,##0.00;[Red]-#,##0.00'
        # Make cover more presentation-friendly
        cover_ws = writer.book["Portada"]
        cover_ws.merge_cells("A1:B1")
        cover_ws["A1"].font = Font(bold=True, color="FFFFFF", size=16)
        cover_ws["A1"].fill = PatternFill("solid", fgColor="173B57")
        cover_ws["A1"].alignment = Alignment(vertical="center")
        cover_ws.row_dimensions[1].height = 34
        cover_ws.column_dimensions["A"].width = 30
        cover_ws.column_dimensions["B"].width = 70
        for row in range(2, cover_ws.max_row + 1):
            cover_ws.cell(row, 1).font = Font(bold=True, color="173B57")
            if row == 6:
                for cell in cover_ws[row]:
                    cell.font = Font(bold=True, color="FFFFFF")
                    cell.fill = PatternFill("solid", fgColor="47708E")
    output.seek(0)
    return output.getvalue()

def summary_frame(frame: pd.DataFrame, dimension: str) -> pd.DataFrame:
    if frame.empty:
        return pd.DataFrame(columns=[dimension, "cantidad_operaciones", "importe_total"])
    work = frame.copy()
    if dimension == "fecha":
        work[dimension] = work[dimension].dt.strftime("%Y-%m-%d")
    return (
        work.groupby(dimension, dropna=False)
        .agg(cantidad_operaciones=("importe", "size"), importe_total=("importe", "sum"))
        .reset_index()
        .sort_values("importe_total", ascending=False)
    )

# ------------------------------- Interfaz -----------------------------------
with st.sidebar:
    st.markdown("### 🦊 MS FOX")
    st.caption("Automatización inteligente de reportes")
    company_name = st.text_input("Nombre de la empresa", value="Empresa Demo")
    period_label = st.text_input("Período del reporte", value="Enero–Febrero 2026")
    st.divider()
    st.markdown("**Regla para detectar duplicados**")
    st.caption("Seleccioná los campos que deben coincidir para marcar un registro como duplicado.")
    key_options = {
        "Fecha": "fecha",
        "Cliente": "cliente",
        "Categoría": "categoria",
        "Importe": "importe",
    }
    selected_labels = st.multiselect(
        "Campos de comparación",
        options=list(key_options.keys()),
        default=["Fecha", "Cliente", "Categoría", "Importe"],
    )
    duplicate_policy = st.radio(
        "Tratamiento para los resúmenes",
        ["Excluir duplicados adicionales", "Incluir todas las filas"],
        help="La primera opción cuenta solo la primera aparición de cada combinación. El consolidado sigue conservando todas las filas válidas.",
    )
    st.divider()
    st.caption("Demo local · no cargar datos confidenciales sin autorización.")

st.markdown('<div class="msfox-eyebrow">MS FOX · SOLUCIONES DIGITALES</div>', unsafe_allow_html=True)
st.markdown('<div class="msfox-title">Consolidador Excel</div>', unsafe_allow_html=True)
st.markdown('<div class="msfox-subtitle">Convertí múltiples planillas en información consolidada, validada y lista para decidir.</div>', unsafe_allow_html=True)
st.write("")

uploads = st.file_uploader(
    "Cargá archivos de ventas, compras o movimientos",
    type=["xlsx", "csv"],
    accept_multiple_files=True,
    help="Cada archivo debe incluir Fecha, Cliente, Categoría e Importe. Podés cargar varios a la vez.",
)

if not uploads:
    st.info("Para iniciar la demo, cargá los dos archivos de ejemplo incluidos en la carpeta `ejemplos`.")
    st.markdown("#### Qué incluye esta demo")
    c1, c2, c3 = st.columns(3)
    c1.markdown("**Consolidación**\n\nUnifica varios archivos en un único conjunto de datos.")
    c2.markdown("**Control de calidad**\n\nMarca duplicados y filas con datos inválidos.")
    c3.markdown("**Reportes**\n\nResume resultados por fecha, cliente o categoría.")
    st.stop()

frames, file_errors = [], []
for upload in uploads:
    try:
        frames.append(clean_file(read_uploaded_file(upload), upload.name))
    except Exception as exc:
        file_errors.append(f"**{upload.name}:** {exc}")

for message in file_errors:
    st.error(message)

if not frames:
    st.warning("No se pudo procesar ningún archivo. Revisá las columnas obligatorias.")
    st.stop()

raw_data = pd.concat(frames, ignore_index=True)
valid = raw_data[raw_data["error_validacion"] == ""].copy()
invalid = raw_data[raw_data["error_validacion"] != ""].copy()

if not selected_labels:
    st.warning("Seleccioná al menos un campo para detectar duplicados.")
    st.stop()

duplicate_keys = [key_options[label] for label in selected_labels]
dup_mask = valid.duplicated(subset=duplicate_keys, keep=False)
duplicates = valid.loc[dup_mask].copy()
valid["es_duplicado"] = valid.duplicated(subset=duplicate_keys, keep="first")
unique_valid = valid.loc[~valid.duplicated(subset=duplicate_keys, keep="first")].copy()
summary_source = unique_valid if duplicate_policy == "Excluir duplicados adicionales" else valid

# ----------------------------- Tablero ---------------------------------------
st.subheader("Tablero ejecutivo")
total_rows = len(raw_data)
valid_rows = len(valid)
invalid_rows = len(invalid)
duplicate_rows = int(dup_mask.sum())
total_amount = float(valid["importe"].sum()) if not valid.empty else 0.0
duplicate_amount = float(duplicates["importe"].sum()) if not duplicates.empty else 0.0
unique_amount = float(summary_source["importe"].sum()) if not summary_source.empty else 0.0

m1, m2, m3, m4 = st.columns(4)
m1.metric("Archivos procesados", len(frames))
m2.metric("Operaciones válidas", f"{valid_rows:,}".replace(",", "."))
m3.metric("Duplicados marcados", f"{duplicate_rows:,}".replace(",", "."))
m4.metric("Filas con errores", f"{invalid_rows:,}".replace(",", "."))

m5, m6 = st.columns(2)
m5.metric("Importe válido total", money(total_amount))
m6.metric("Importe en filas duplicadas", money(duplicate_amount))

if invalid_rows:
    st.warning(f"Se detectaron {invalid_rows} filas con errores de validación. Revisá la pestaña de errores en el reporte.")
if duplicate_rows:
    st.warning("Hay registros que coinciden con la regla seleccionada. Confirmá si son duplicados reales antes de excluirlos de un informe financiero.")

tab_overview, tab_summary, tab_data, tab_quality = st.tabs(
    ["Vista general", "Resúmenes", "Consolidado", "Calidad de datos"]
)
with tab_overview:
    st.markdown("#### Distribución por categoría")
    if not summary_source.empty:
        cat = summary_source.groupby("categoria", dropna=False)["importe"].sum().sort_values(ascending=False)
        st.bar_chart(cat)
    else:
        st.info("No hay registros válidos para graficar.")
    st.markdown("#### Evolución por fecha")
    if not summary_source.empty:
        daily = summary_source.assign(fecha_dia=summary_source["fecha"].dt.strftime("%Y-%m-%d")).groupby("fecha_dia")["importe"].sum().sort_index()
        st.line_chart(daily)
    else:
        st.info("No hay datos para mostrar.")

with tab_summary:
    dimension_label = st.selectbox("Agrupar resumen por", ["Fecha", "Cliente", "Categoría"], key="summary_dimension")
    dimension = {"Fecha": "fecha", "Cliente": "cliente", "Categoría": "categoria"}[dimension_label]
    summary = summary_frame(summary_source, dimension)
    st.dataframe(summary, use_container_width=True, hide_index=True)
    if not summary.empty:
        st.download_button(
            "Descargar resumen CSV",
            data=summary.to_csv(index=False).encode("utf-8-sig"),
            file_name="resumen_msfox.csv",
            mime="text/csv",
        )

with tab_data:
    st.caption("El consolidado conserva todas las filas válidas, incluso las marcadas como duplicadas.")
    st.dataframe(valid.drop(columns=["error_validacion"]), use_container_width=True, hide_index=True)

with tab_quality:
    st.markdown("#### Registros marcados como duplicados")
    st.caption("Regla actual: " + " + ".join(selected_labels))
    if duplicates.empty:
        st.success("No se detectaron duplicados con la regla elegida.")
    else:
        st.dataframe(duplicates, use_container_width=True, hide_index=True)
    st.markdown("#### Filas con errores")
    if invalid.empty:
        st.success("No se detectaron errores básicos de validación.")
    else:
        st.dataframe(invalid, use_container_width=True, hide_index=True)

# ------------------------------ Exportación ----------------------------------
st.subheader("Reporte profesional")
st.caption("El archivo incluye portada, resumen ejecutivo, consolidado, duplicados y errores.")
summary_for_export = summary_frame(summary_source, "fecha")
by_client = summary_frame(summary_source, "cliente")
by_category = summary_frame(summary_source, "categoria")
export_sheets = {
    "Resumen por fecha": summary_for_export,
    "Resumen por cliente": by_client,
    "Resumen por categoria": by_category,
    "Consolidado": valid.drop(columns=["error_validacion"]),
    "Duplicados": duplicates,
    "Errores": invalid,
}
period = period_label.strip() or "No especificado"
company = company_name.strip() or "Empresa Demo"
generated = datetime.now().strftime("%d/%m/%Y %H:%M")
excel_data = build_excel_bytes(export_sheets, company, period, generated)
safe_company = "".join(ch if ch.isalnum() else "_" for ch in company).strip("_") or "empresa"
st.download_button(
    "⬇️ Descargar reporte profesional MS FOX (.xlsx)",
    data=excel_data,
    file_name=f"MSFOX_reporte_{safe_company}.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    type="primary",
)
st.caption("MS FOX · Demo comercial local. Verificá las reglas de negocio antes de utilizar resultados para decisiones financieras.")
