# MS FOX — Consolidador Excel v2

Demo comercial local con:
- Carga de varios archivos `.xlsx` y `.csv`.
- Normalización de columnas comunes.
- Validación de fecha, cliente, categoría e importe.
- Detección de duplicados configurable por campos seleccionados.
- Tablero ejecutivo con métricas y gráficos por categoría/fecha.
- Resúmenes por fecha, cliente y categoría.
- Exportación Excel con portada, hojas de resumen, consolidado, duplicados y errores.

## Requisitos
- Python 3.10 o superior (recomendado Python 3.11/3.12).
- Internet solo para instalar las dependencias iniciales.

## Instalación en Windows
Abra CMD o PowerShell dentro de la carpeta del proyecto:

```powershell
py -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

Si `py` no existe, pruebe `python -m venv .venv`.

## Instalación en macOS/Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

La aplicación estará disponible normalmente en `http://localhost:8501`.

## Prueba recomendada
Cargue juntos:
- `ejemplos/ventas_enero.xlsx`
- `ejemplos/ventas_febrero.xlsx`

Estos archivos comparten una fila intencionalmente duplicada para mostrar la función de detección. También puede probar `ventas_con_errores.xlsx` para ver las validaciones y `ventas_extra.csv` para probar CSV.

## Formato esperado
Columnas obligatorias: Fecha, Cliente, Categoria, Importe. Se aceptan algunos alias habituales como Date, Customer, Monto, Total, Proveedor o Rubro.

## Regla de duplicados
La aplicación permite seleccionar cualquier combinación de Fecha, Cliente, Categoría e Importe. Todas las filas que coinciden en los campos seleccionados se marcan como duplicadas. El consolidado conserva todas las filas válidas; el selector controla si los resúmenes excluyen repeticiones adicionales o incluyen todas las filas.

Importante: si no existe un identificador único, dos operaciones legítimas pueden coincidir. Acordar la regla con el cliente antes de usar los resultados para decisiones contables o financieras.

## Limitaciones de la demo
- Ejecuta localmente y no incluye login, permisos multiempresa, auditoría ni backups.
- Los datos permanecen en la sesión de la aplicación local; no está preparada para publicar en internet sin endurecimiento de seguridad.
- No carga macros ni procesa archivos `.xls` antiguos.
- Probá primero con datos ficticios o anonimizados.
